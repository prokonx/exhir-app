<?php

namespace App\Http\Controllers;

use App\Http\Requests;
use Illuminate\Http\Request;

use App\AdminQuestion;

use App\AdminOption;

use App\User;

use Validator;

use Redirect;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        //$this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('home');
    }

    public function install() {

        $questions = AdminQuestion::where('type' , 'dropdown')->orderBy('created_at' , 'desc')->get();

        $slider = AdminQuestion::where('type' , 'slider')->orderBy('created_at' , 'desc')->get();

        $count = AdminQuestion::count();

        return view('install')->with('questions' , $questions)->with('slider' , $slider)->with('count' , $count);
    }

    public function installSubmit(Request $request) {

        $question = $request->question;

        $type = $request->type;

        $validator = Validator::make($request->all() ,
            [
                'question' => 'required',
                'type' => 'required',
            ]);

        if ($validator->fails()) 
        {
            $error_messages = $validator->messages()->all();

            return back()->withErrors($validator)
                        ->withInput()
                        ->with('flash_errors' , $error_messages);
        }
        else 
        {

            $question = new AdminQuestion;

            $question->question = $request->question;
            $question->type = $request->type;
            $code = rand(100, 999);
            $question->code = 'QN'.$code;
            $question->save();

            if($question) {

                if($request->type == "dropdown") {


                    if($request->has('option')) {

                        foreach ($request->option as $key => $options) {

                            $option = new AdminOption;
                            $o_code = rand(1000, 9999);
                            $option->code = 'QN'.$o_code;
                            $option->question_id = $question->id;
                            $option->option = $options;
                            $option->save();
                        
                        }

                    }

                }
            }

            return Redirect::back()->with('flash_success' , "Successfully question added");
        }
    
    }

    public function deleteinstallQuestion(Request $request)
    {
        $id = $request->id;

        if($admin_question = AdminQuestion::find($id)) {

            $adminOptions = AdminOption::where('question_id',$id)->delete();

            $adminQuestions = AdminQuestion::where('id',$id)->delete();    

            if($adminQuestions)
            {
                return back()->with('flash_success',"Deleted successfully");
            } else {
                return back()->with('flash_error',"Something went wrong");
            }
        } else {

            return back()->with('flash_error',"Question ID not found");
        }
        

        
    }

    public function register(Request $request)
    {
        $device_token = $request->device_token;
        $device_type = $request->device_type;
        $gcm    = $request->gcm;
        $user_id    = $request->user_id;

        $validator = Validator::make(
            array(
                'device_token' => $device_token,
                'device_type' => $device_type,
                'user_id' => $user_id,
            ), array(
                'device_token' => 'required',
                'device_type' => 'required',
                'user_id' => 'required',
            )
        );

        if ($validator->fails())
        {
            $error_messages = $validator->messages()->all();
            $response_array = array('success' => false, 'error' => 'Invalid Input', 'error_code' => 401, 'error_messages' => $error_messages);
            $response_code = 200;
        }
        else
        {
            $user = User::find($user_id);


            if (count($user) != 0)
            {
                $user->device_type = $device_type;
                $user->device_token = $device_token;

                if($request->has('gcm'))
                {
                    $user->gcm = $gcm;
                }
                $user->save();

                $response_array = array('success' => true, 'message' => 'Device Register Successfully');
            }
            else
            {
                $response_array = array('success' => false, 'message' => 'User ID not found');
            }
        }

        return response()->json($response_array);

        //return Response::json($response_array);
    }
}
