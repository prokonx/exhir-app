<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use App\User;

use App\UserImage;

use App\UserPreference;

use App\UserQuestion;

use App\Report;

use App\Message;

use App\Payments;

use App\AdminQuestion;

use App\AdminOption;

use App\UserOption;

use App\City;

use App\Subhub;

use Validator;

use Hash;

use Mail;

use App\Admin;

use DB;

use Redirect;

use Setting;

use App\Page;

use App\Like;

use Auth;

use Session;

use Carbon\Carbon;

class AdminController extends Controller
{
    public function adminDashboard()
    {

    	$user_count = User::count();
    	$swipe = Like::count();

    	  $ios_count = User::where('device_type','ios')->count();
          $android_count = User::where('device_type','android')->count();

          $device = array();

          $device['ios'] = $ios_count;
          $device['android'] = $android_count;

          $male_count = User::where('gender','male')->count();
          $female_count = User::where('gender','female')->count();

          $gender = array();

          $gender['male'] = $male_count;
          $gender['female'] = $female_count;

          $cities = City::count();

          $sub_urbs = Subhub::count();


          $admin_questions = AdminQuestion::all();

         if(count($admin_questions) > 0) {

    		return view('admin.adminDashboard')->withPage('dashboard')->with('title' , 'Dashboard')->withGender($gender)->withDevice($device)->withCities($cities)->withSub_urbs($sub_urbs)->withUserCount($user_count)->withSwipe($swipe);
    		
    	} else {
    		
    		return \Redirect::route('install');
    	}
    }

    public function userManagement()
	{

		if($user = User::orderBy('created_at' , 'desc')->paginate(10))
		{
			return view('admin.userManagement')
				->with('title',"User Management")
				->with('page',"users")
				->with('users',$user);
		}
		else
		{
			return Redirect::back()->with('flash_error',"Something went wrong");
		}
	}

	public function adminAddUser()
	{
		return view('admin.addUser')->with('title' , 'Add User')->withPage('users');
	}

	public function adminUserEdit($id)
	{
		$user = User::find($id);

		if($user)
		{
			return view('admin.editUser')->with('title' , 'Edit User')->withPage('users')->withUser($user);
		}
		else
		{
			return back()->with('flash_error',"Something went wrong");
		}
	}

	public function addUserProcess(Request $request)
	{
		$validator = Validator::make($request->all(), [
            'username' => 'required',
            'email' => 'required|email',
        ]);
        $email = $request->email;

        if ($validator->fails()) 
        {
            return back()->withErrors($validator)
                        ->withInput();
        }
		else 
		{
			if ($request->id != "") 
            {
            	$user = User::find($request->id);
				$user->email = $request->email;
				$user->name = $request->username;
				$user->is_activated = 1;
				
            }
            else
            {
            	$user = User::where('email', $request->email)->first();
				if ($user) {
					$error = "User already exists";
					return back()->with('flash_error', $error);
				}
            	$user = new User;
				$user->email = $request->email;
				$user->name = $request->username;
                $user->is_activated = 1;

				$new_password = time();
				$new_password .= rand();
				$new_password = sha1($new_password);
				$new_password = substr($new_password, 0, 8);
				$user->password = Hash::make($new_password);


				$subject = "Welcome On Board";
				$email_data['name'] = $user->name;
				$email_data['password'] = $new_password;
				$email_data['email'] = $user->email;
				
				try
				{
					Mail::send('emails.newmoderator', array('email_data' => $email_data), function ($message) use ($email, $subject) {
                    $message->to($email)->subject($subject);
                    });

				}				
				catch(Exception $e)
				{
					return back()->with('flash_error', "Something went wrong in mail configuration");
				}
				
            }

			$user->save();

			if ($user) {

				$s3_url = asset('flamerui/img/user.png');

                for($i=0;$i<5;$i++) {

                	$user_image = new UserImage;
                	$user_image->position = $i+1;
                	$user_image->user_id = $user->id;
                	$user_image->image = $s3_url;
                	$user_image->status = 0;
                	$user_image->save();
                }

				if($user_prefer = UserPreference::where('user_id' , $user->id)->first()) {

					$user_preference = $user_prefer;

				} else {
					
					$user_preference = new UserPreference;

					if($user->gender == "female") {
						$user_preference->gender = 'male';
					} else {
						$user_preference->gender = 'female';
					}

					$user_preference->age_limit = 25;
					$user_preference->distance = 50;
					$user_preference->discovery = 1;
					/*$user_preference->latitude = $latitude;
					$user_preference->longitude = $longitude;*/
					$user_preference->user_id = $user->id;
					$user_preference->save();
				
				}

				return back()->with('flash_success', "User updated Successfully");
			} else {
				return back()->with('flash_error', "Something went wrong");
			}
		}
	}

	public function userActivate($id)
	{
		$user = User::find($id);
		$user->is_activated = 1;
		$user->save();
		if($user)
		{
			return back()->with('flash_success',"User Activated successfully");
		}
		else
		{
			return back()->with('flash_error',"Something went Wrong");
		}
	}

	public function userDecline($id)
	{
		$user = User::find($id);
		$user->is_activated = 0;
		$user->save();
		if($user)
		{
			return back()->with('flash_success',"User Declined successfully");
		}
		else
		{
			return back()->with('flash_error',"Something went Wrong");
		}
	}

	public function userDelete($id)
	{

        if($user_details = User::find($id)) 
        {

        	$user_id = $user_details->id;

        	$user_preference = UserPreference::where('user_id' , $user_id)->delete();
			$user_question 	= UserQuestion::where('user_id' , $user_id)->delete();
			$user_report = Report::where('user_id' , $user_id)->orWhere('report_user' , $user_id)->delete();
			$user_payment = Payments::where('user_id' , $user_id)->delete();
			$user_images = UserImage::where('user_id' , $user_id)->delete();
			$user_images = Like::where('user_id' , $user_id)->orWhere('suggestion_id' , $user_id)->delete();
			$user_images = Message::where('sender_id' , $user_id)->orWhere('receiver_id' , $user_id)->delete();

            $user = User::find($id)->delete();
        }

		if($user)
		{
			return back()->with('flash_success',"User deleted successfully");
		}
		else
		{
			return back()->with('flash_error',"Something went Wrong");
		}
	}

    public function filterUsers(Request $request,$flag)
    {
        if($request->has('keyword'))
        {
            $q = $request->keyword;

            $feeds = User::orderBy('created_at','desc')
            			->distinct()
            			->orWhere('name','like', '%'.$q.'%')
            			->orWhere('email','like', '%'.$q.'%');

            $slide = 'recentuser';

            if(!$feeds)
            {
                return back()->with('flash_error',"Result not found");
            }
        }
        else
        {
            if($flag == 1) // flag = 1 for recent, flag =2 for trending, flag = 4 for untrending, flag=4 for activated, flag = 5 for unactivated
            {
                $feeds = User::orderBy('name','asc');
                $slide = 'recentuser';
            }
            elseif($flag == 2)
            {
                $feeds = User::orderBy('created_at','desc');
                $slide = 'recentuser';
            }
            elseif($flag == 3)
            {
                $feeds = User::orderBy('created_at','desc');
                $slide = 'untrendin';
            }
            elseif($flag == 4)
            {
                $feeds = User::where('is_activated' , 1)->orderBy('name','desc');
                $slide = 'activated';
            }
            elseif($flag == 5)
            {
                $feeds = User::where('is_activated' , 0)->orderBy('created_at','desc');
                $slide = 'unactivated';
            }
            elseif($flag == 6)
            {
                $category_id = $request->topics;

                if($request->topics && !$request->feed_date)
                {
                    Session::put('topi',$request->topics);
                    $feeds = User::where('status',$request->topics)->orderBy('created_at','desc');
                    $slide = 'category-id';
                }
                else
                {
                    if(Session::has('topi'))
                    {
                        $top = Session::get('topi');
                        $feeds = User::where('status',Input::get('topics'))->orderBy('created_at','desc');
                        $slide = 'category-id';
                    }
                    else
                    {
                        $feeds = User::orderBy('created_at','desc');
                        $slide = 'category-id';
                    }
                }

                if($request->has('feed_date') && !$request->has('topics')) {

                    $s_date = date('Y-m-d H:i:s', strtotime($request->feed_date));
                    $e_date = date('Y-m-d H:i:s',strtotime($request->feed_date." "."23:59:59"));
                    
                    Session::put('topi',$request->feed_date);

                    $feeds = User::where('requests.created_at', '>=', $s_date )
                                    ->where('requests.created_at', '<=', $e_date )->where('requests.status','!=', 0);

                    //Log::info($feeds);
                    $slide = 'feed-date';
                }

                if($request->has('feed_date') && $request->has('topics')) {

                    $s_date = date('Y-m-d H:i:s', strtotime($request->feed_date));
                    $e_date = date('Y-m-d H:i:s',strtotime($request->feed_date." "."23:59:59"));
                    
                    Session::put('topi',Input::get('feed_date'));

                    $feeds = User::where('created_at', '>=', $s_date )
                                    ->where('requests.created_at', '<=', $e_date )
                                    ->where('status' , $request->topics);

                    Log::info($feeds);

                    $slide = 'feed-date and Topic';
                }
            }
            else
            {
                return back()->with('flash_error',"Something went wrong");
            }
        }
        if($feeds)
        {
        	$users = $feeds->paginate(10);

            return view('admin.userManagement')
                ->with('title',"Request Management")
                ->with('page',"users")
                ->with('users',$users);
        }
        else
        {
            return Redirect::back()->with('flash_error',"Something went wrong");
        }
    }

    public function setting()
	{
		return view('admin.setting')
			->with('title',"Settings")
			->with('page', "admin_setting");
	}

	public function settingProcess(Request $request)
	{

		$validator = Validator::make(array(
			'sitename' => $request->sitename),
			array('sitename' => 'required'));
		if($validator->fails())
		{
			$errors = $validator->messages()->all();
			return Redirect::back()->with('flash_errors',$errors);
		}
		else
		{
			$validator1 = Validator::make(
				array(
					'picture' => $request->file('picture')
				),
				array(
					'picture' => 'required|mimes:png')
				);
			if($validator1->fails())
			{
				// do nothing
			}
			else
			{				
				$file_name = time();
				$file_name .= rand();
				$ext = $request->file('picture')->getClientOriginalExtension();
				$request->file('picture')->move(base_path()."/../uploads", $file_name . "." . $ext);
				$local_url = $file_name . "." . $ext;
				$s3_url = url('/uploads/' . $local_url);
				Setting::set('logo', $s3_url);

			}

			if($request->hasFile('favicon')) {

				$file_name = time();
				$file_name .= rand();
				$ext = $request->file('favicon')->getClientOriginalExtension();
				$request->file('favicon')->move(base_path()."/../uploads", $file_name . "." . $ext);
				$local_url = $file_name . "." . $ext;
				$s3_url = url('/uploads/' . $local_url);
				
				Setting::set('favicon', $s3_url);

			}

			Setting::set('sitename', $request->sitename);
			Setting::set('footer', $request->footer);
			Setting::set('google_play', $request->google_play);
			Setting::set('ios_app', $request->ios_app);
			Setting::set('website_link', $request->website_link);
			Setting::set('timezone', $request->timezone);
			Setting::set('browser_key', $request->browser_key);
			Setting::set('radius', $request->radius);
			Setting::set('like_limit_count', $request->like_limit_count);
			Setting::set('superlike_limit_count', $request->superlike_limit_count);
			Setting::set('search_radius', $request->search_radius);
			Setting::set('paypal_email',$request->paypal_email);
			Setting::set('paypal_price',$request->paypal_price);
			Setting::set('home_tag',$request->home_tag);
			//Setting::set('favicon',$request->favicon);
		

			return Redirect::back()->with('flash_success', "Settings updated successfully");
		}
	}

	public function mailConfig(Request $request)
	{
		if($request->mail_type == "mandrill")
		{
			Setting::set('mail_type',"mandrill");
			Setting::set('smtp_host',"smtp.mandrillapp.com");
			Setting::set('mail_username',$request->username);
			Setting::set('secret',$request->password);
		}
		elseif($request->mail_type == "normal_smtp")
		{
			Setting::set('mail_type',"smtp");
			Setting::set('smtp_host',"smtp.gmail.com");
			Setting::set('mail_username',$request->username);
			Setting::set('secret',$request->password);
		}

		return Redirect::back()->with('flash_success',"Mail Configured successfully");
	}

	public function adminProfile()
	{
		$admin = auth()->guard('admin')->user();
		return view('admin.profile')
			->with('title',"Admin Profile")
			->with('page', "account")
			->with('admin',$admin);
	}

	public function adminProfileProcess(Request $request)
	{
		$validator = Validator::make($request->all(), [
            'name' => 'required',
            'email' => 'required|email',
        ]);

		if($validator->fails())
		{
			$error = $validator->messages()->all();
			return back()->with('flash_errors',$error);
		}
		else
		{
			$name = $request->name;
			$email = $request->email;
			$admin = Admin::find(1);
			$admin->name = $name;
			$admin->email = $email;
			$admin->save();

			if ($admin)
			{
				return back()->with('flash_success', "Admin updated successfully");
			}
			else
			{
				return back()->with('flash_error', "Something went wrong");
			}
		}
	}

	public function adminPassword(Request $request)
	{
		$validator = Validator::make($request->all(),
			array('password' => 'required',
				'con_password' => 'required'));
		if($validator->fails())
		{
			$error = $validator->messages()->all();
			return back()->with('flash_errors',$error);
		}
		else
		{
			$password = $request->password;
			$con_password = $request->con_password;
			$admin = Admin::find(1);
			$admin->password = Hash::make($con_password);
			$admin->save();

			if ($admin) {
				return back()->with('flash_success', "Password updated successfully");
			} else {
				return back()->with('flash_error', "Something went wrong");
			}
		}
	}

	public function profilePics(Request $request)
	{
		$validator = Validator::make($request->all(),
			array('profile_pic' => 'required|mimes:jpeg,bmp,gif,png'));
		if($validator->fails())
		{
			$error = $validator->messages()->all();
			return back()->with('flash_errors',$error);
		}
		else
		{
			$admin = Admin::find(1);
			$file_name = time();
			$file_name .= rand();
			$ext = $request->file('profile_pic')->getClientOriginalExtension();
			$request->file('profile_pic')->move(base_path()."/../uploads", $file_name . "." . $ext);
			$local_url = $file_name . "." . $ext;
			$s3_url = url('/') . '/uploads/' . $local_url;
			$admin->profile_pic = $s3_url;
			$admin->save();

			if ($admin) {
				return back()->with('flash_success', "Admin updated successfully");
			} else {
				return back()->with('flash_error', "Something went wrong");
			}
		}
	}

	public function paymentDetails() {

		$payments = Payments::orderBy('payments.created_at' , 'desc')
							->leftJoin('users' , 'payments.user_id' ,'=' , 'users.id')
							->select('users.name as name' , 'users.id as user_id' ,'payments.id as payment_id' ,
								'payments.paypal_email' , 'payments.paypal_id' , 'payments.paid_amount' , 'payments.paid_status',
								'payments.created_at as time')
							->paginate(20);

		return view('admin.payments')
			->with('title',"payments")
			->with('payments',$payments)
			->with('page', "payments");
	}

	public function paymentDelete($id) {

		$payments = Payments::where('id',$id)->delete();

		if($payments)
		{
			return back()->with('flash_success',"Payment deleted successfully");
		}
		else
		{
			return back()->with('flash_error',"Something went wrong");
		}
	}

	public function list_message($id) 
    {

        $user = User::find($id);
        $select_user = User::find($id);

        $username = $user->id;

        $messages = Message::
            where('receiver_id', $username)
            ->orWhere('sender_id' , $username)
            ->orderBy('updated_at' , 'DESC')
            ->get();

        $alluser = [];

        $default = Message::where('receiver_id', $username)
            ->orWhere('sender_id' , $username)
            ->orderBy('updated_at' , 'DESC')
            ->first();

            $de = "";


        if($default) {

            if($default->sender_id == $user->id) {
                $sender = User::where('id' , $default->receiver_id)->first();
                $receiver = $user;
            } elseif($default->receiver_id == $user->id) 
            {
                $sender = User::where('id' , $default->sender_id)->first();
                $receiver = $user;
            }

            $default_messages = Message::
                where('receiver_id', $default->receiver_id)
                ->orwhere('receiver_id', $default->sender_id)
                ->Where('sender_id' , $default->sender_id)
                ->orWhere('sender_id' , $default->receiver_id)
                ->get();


            $de =  view('admin.userIndividualMessage')
                            ->with('sender' , $sender)
                            ->with('user' , $receiver)
                            ->with('messages' , $default_messages);
        } else {
            $de = "";
        }


        foreach($messages as $m => $message) 
        {

            if($message->sender_id == $username) {
                $alluser[] = $message->receiver_id;
            } else {
                $alluser[] = $message->sender_id;
            }

        }

        $users = array_unique($alluser);

        return view('admin.usermessage')
                ->with('page' , 'messages')
                ->with('title' , 'Messages')
                ->with('messages' , $messages)
                ->with('user' , $user)
                ->with('select_user' , $select_user)
                ->with('home_active' ,'')
                ->with('de' , $de)
                ->with('notification_active' , '')
                ->with('message_active' , 'radar-active')
                ->with('title' , 'Messages')
                ->with('page' , 'messages')
                ->with('users' , $users);
    }

    public function AdminIndividualMessage(Request $request) {

		$auth_user = $request->auth_user;

		$receiver = User::find($auth_user);

        $user = $request->user;

        $sender = User::where('id' , $user)->first();

        $messages = Message::where('receiver_id', $user)
            			->orWhere('sender_id' , $receiver->id)
            			->orwhere('receiver_id' , $receiver->id)
            			->orWhere('sender_id' ,$user)
            			->get();

        return view('admin.userIndividualMessage')
                        ->with('sender' , $sender)
                        ->with('user' , $receiver)
                        ->with('title' , 'Message')
                        ->with('messages' , $messages);
	
	}
	
	public function questions(Request $requst) {

		$questions = AdminQuestion::where('type' , 'dropdown')->paginate(10);

		return view('admin.questions')
						->with('title',"Questions")
						->with('page',"questions")
						->with('questions' , $questions);
	}

	public function adminQuestionProcess(Request $request) {

		if($request->id != "") {

			$question = AdminQuestion::find($request->id);

		} else {
			
			$question = new AdminQuestion;

		}


		$question->question = $request->question;
		$question->type = $request->type;
		$code = rand(100, 999);
		$question->code = 'QN'.$code;
		$question->save();

		if($question) {

			if($request->type == "dropdown") {


				if($request->has('option')) {

					foreach ($request->option as $key => $options) {

						$option = new AdminOption;
						$o_code = rand(1000, 9999);
						$option->code = 'QN'.$o_code;
						$option->question_id = $question->id;
						$option->option = $options;
						$option->save();
					
					}

				}

			}
		
		}

		return Redirect::route('adminQuestions')->with('flash_success' , "Questions added successfully");
	
	}

	public function editQuestion(Request $request) {

		$question_id = $request->id;

		$question = AdminQuestion::find($question_id);

		return view('admin.edit-questions')
				->with('title' , "Edit Questions")
				->with('page' , 'Edit Questions')
				->with('question' , $question);


	} 

	public function options(Request $request) {

		$id = $request->id;

		$question = AdminQuestion::find($id);

		$options = AdminOption::where('question_id' , $id)->paginate(20);

		return view('admin.edit-options')->with('title' , 'Edit Options')
					->with('page' , 'questions')
					->with('editOption' , array())
					->with('question' , $question)
					->with('options' , $options);

	}

	public function editOption(Request $request) {

		$option_id = $request->option_id;

		$question_id = $request->question_id;

		if($option = AdminOption::find($option_id)) {

			$question = AdminQuestion::find($question_id);

			$options = AdminOption::where('id' , '!=' , $option_id)->where('question_id' , $question_id)->paginate(10);

			return view('admin.edit-options')
					->with('title' , 'Edit Options')
					->with('page' , 'questions')
					->with('editOption' , $option)
					->with('question' , $question)
					->with('options' , $options);

		} else {

			return back()->with('flash_error' , 'Option not found');
		}

	}

	public function editOptionProcess(Request $request) {

		$option_id = $request->id;
		$question_id = $request->question_id;
		$option_val = $request->option;

		if($option = AdminOption::find($option_id)) {

			$option->option = $option_val;
			$option->save();

			return Redirect::back()->with('flash_success' , 'Option updated successfully');

		} else {

			return back()->with('flash_error' , 'Something went wrong');

		}

	}

	public function cityManagement() {

		if($cities = City::orderBy('city' , 'asc')->paginate(10))
		{
			return view('admin.cityManagement')
				->with('title',"City Management")
				->with('page',"cities")
				->with('cities',$cities);
		}
		else
		{
			return Redirect::back()->with('flash_error',"Something went wrong");
		}
	}

	public function addCity() {

		return view('admin.addCity')
					->with('title',"Cities")
					->with('page',"cities");
	}

	public function addCityProcess(Request $request) {

		$address = $request->city;

		$validator = Validator::make($request->all(),
			array( 
				'city' => 'required',

			));

		if($validator->fails())
		{
			$error = $validator->messages()->all();
			return back()->with('flash_errors',$error);
		}
		else
		{
			if(!$request->has('id')) {

				if($check_city = City::find($request->id)) {
					$city = $check_city;
				} else {
					$city = new City;
				}
				
			} else{
				$city = City::where('id' , $request->id)->first();
			}

			if($request->has('city')){ 
				$city->city = $address;
			}

			$city->save();

			if ($city) {
				return back()->with('flash_success', "City added successfully");
			} else {
				return back()->with('flash_error', "Something went wrong");
			}
		}
	
	}

	public function editCity(Request $request) {

		if($city_details = City::find($request->id)) {

			return view('admin.editCity')->with('title',"Cities")
					->with('page',"cities")->with('city',$city_details);

		} else {

			return back()->with('flash_error',"Something went Wrong");

		}
	
	}

	public function cityDelete(Request $request) {

		if($city = City::find($request->id)) 
        {

            $city_details = City::find($request->id)->delete();
        }

		if($city_details)
		{
			return back()->with('flash_success',"City deleted successfully");
		}
		else
		{
			return back()->with('flash_error',"Something went Wrong");
		}
	
	}

	public function addsubhub(Request $request) {

		if($city = City::find($request->id)) {

			$subhubs = Subhub::where('city_id' , $city->id)->paginate(10);

			return view('admin.addsubhub')
						->with('city',$city)
						->with('subhubs',$subhubs)
						->with('title',"addsubhub")
						->with('page',"cities");
		} else {

			return Redirect::back()->with('flash_error' , 'City Not Found');
		}

	}

	public function addsubhubprocess(Request $request) {

		$subhub = $request->subhub;
		$id = $request->id;

		$validator = Validator::make($request->all(),
			array( 
				'subhub' => 'required',

			));

		if($validator->fails())
		{
			$error = $validator->messages()->all();
			return back()->with('flash_errors',$error);
		}
		else
		{
			if($request->has('id')) {

				if($city = City::where('id' , $request->id)->first()) {

					$subhub_obj = new Subhub;
					$subhub_obj->city_id = $id;
					$subhub_obj->subhub = $subhub;
					$subhub_obj->save();

					if($subhub_obj) {

						return back()->with('flash_success', "Suburb Added Successfully")->with('city' , $city);

					} else {
						return back()->with('flash_error', "Something went wrong");
					}
				} else {
					return back()->with('flash_error', "Something went wrong");
				}

			} else {
				return back()->with('flash_error' , 'City ID not found');
			}

		}
	
	}



	public function editSubhub(Request $request) {

		if($subhub_details = Subhub::find($request->id)) {

			$city_id = $request->city_id;

			$city = City::find($city_id);

			$subhubs = Subhub::where('city_id' , $city_id)->where('id' , '!=' , $request->id)->paginate(5);

			return view('admin.editsubhub')->with('title',"Subhub")
					->with('page',"cities")
					->with('subhubs' , $subhubs)
					->with('city' , $city)
					->with('subhub_details',$subhub_details);

		} else {

			return back()->with('flash_error',"Something went Wrong");

		}
	
	}

	public function editSubhubProcess(Request $request) {


		$subhub_id = $request->id;
		$subhub_content = $request->subhub;

		if($subhub = Subhub::find($subhub_id)) {

			$subhub->subhub = $subhub_content;
			$subhub->save();

			return Redirect::back()->with('flash_success' , 'Subrub updated successfully');

		} else {

			return back()->with('flash_error' , 'Something went wrong');

		}

	}

	public function subhubDelete(Request $request) {

		if($subhub = Subhub::find($request->id)) 
        {

            $subhub_details = Subhub::find($request->id)->delete();
        }

		if($subhub_details)
		{
			return back()->with('flash_success',"Suburb deleted successfully");
		}
		else
		{
			return back()->with('flash_error',"Something went Wrong");
		}
	
	}

	public function viewPages()
	{
		$all_pages = Page::all();
		return view('admin.viewpages')->with('title' , 'Pages')->with('page',"viewpage")->with('view_pages',$all_pages);
	}

	public function pages()
	{
		$pages = Page::all();
		return view('admin.pages')->with('title' , 'Pages')->with('page',"viewpage")->with('view_pages',$pages);
	}

	public function editPage($id)
	{
		$page = Page::find($id);
		if($page)
		{
			return view('admin.editPage')->with('title' , 'Edit Pages')->withPage('viewpage')->with('pages',$page);
		}
		else
		{
			return back()->with('flash_error',"Something went wrong");
		}
	}

	public function pagesProcess(Request $request)
	{
		$type = $request->type;
		$id = $request->id;
		$heading = $request->heading;
		$description = $request->description;

		$validator = Validator::make(array(
			'heading' => $request->heading,
			'description' => $request->description),
			array('heading' => 'required',
				'description' => 'required'));
		if($validator->fails())
		{
			$error = $validator->messages()->all();
			return back()->with('flash_errors',$error);
		}
		else
		{
			if($request->has('id'))
			{
				$pages = Page::find($id);
				$pages->heading = $heading;
				$pages->description = $description;
				$pages->save();
			}
			else
			{
				$check_page = Page::where('type',$type)->first();
				if(!$check_page)
				{
					$pages = new Page;
					$pages->type = $type;
					$pages->heading = $heading;
					$pages->description = $description;
					$pages->save();
				}
				else
				{
					return back()->with('flash_error',"Page already added");
				}
			}
			if($pages)
			{
				return back()->with('flash_success',"Page added successfully");
			}
			else
			{
				return back()->with('flash_error',"Something went wrong");
			}
		}
	}

	public function deletePage($id)
	{
		$page = Page::where('id',$id)->delete();

		if($page)
		{
			return back()->with('flash_success',"Page deleted successfully");
		}
		else
		{
			return back()->with('flash_error',"Something went wrong");
		}
	}

	public function help()
	{
		return view('admin.help')->with('title' , 'Help')->withPage('help');
	}

	public function customPush() {

		return view('admin.push')->with('title' , "Custom Push")->with('page' , "send_push");

	}

	public function customPushProcess(Request $request) 
	{
		$validator = Validator::make(array(
			'content' => $request->content),
			array('content' => 'required'));
		if($validator->fails())
		{
			$error = $validator->messages()->all();
			return back()->with('flash_errors',$error);
		}
		else
		{
			$content = $request->content;
			$title = Setting::get('sitename');
			$message = $content;
			$url = "single.html";
			$status = "custom";
			
			\Log::info($message);

	        send_notifications($title,$message,"","",$url,$status);

	        return back()->with('flash_success' , "Push Notifications sent successfully");
    	}
	}

	public function forgotPassword() 
	{
        return view('admin.forgot-password')->with('title' , 'Login');
    }

    public function processForgotpassword(Request $request) {

            $email = $request->email;
        
            $user = Admin::where('email',$email)->first();

            if(!$user)
            {
                return back()->with('flash_error',"Email ID Not found");
            }

            $new_password = time();
            $new_password .= rand();
            $new_password = sha1($new_password);
            $new_password = substr($new_password, 0, 8);
            $user->password = Hash::make($new_password);

            $subject = "Your New Password";
            $email_data['name'] = $user->author_name;
            $email_data['password'] = $new_password;
            $email_data['email'] = $user->email;

            if($user)
            {
                try
                {
                    Mail::send('emails.newmoderator', array('email_data' => $email_data), function ($message) use ($email, $subject) {
                    $message->to($email)->subject($subject);
                    });

                }
                catch(Exception $e)
                {
                    return back()->with('flash_error',"Mail Config is wrong");
                }

                $user->save();

                return back()->with('flash_success',"The new password is sent to the Email address");

            }
    }

}
















