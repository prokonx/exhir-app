<?php

namespace App\Events;

use App\Events\Event;
use Illuminate\Queue\SerializesModels;
use Illuminate\Contracts\Broadcasting\ShouldBroadcast;


class FacebookInterest extends Event
{
    use SerializesModels;

    public $access_token;

    /**
     * Create a new event instance.
     *
     * @return void
     */
    public function __construct($access_token)
    {
        $this->access_token = $access_token;
    }

    /**
     * Get the channels the event should be broadcast on.
     *
     * @return array
     */
    public function broadcastOn()
    {
        return [];
    }
}
