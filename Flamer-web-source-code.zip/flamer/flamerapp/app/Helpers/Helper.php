<?php

   namespace App\Helpers;

    class Helper
    {
        public static function tes($user_id)
        {
        	if($user_id)
        	{
        		return "true";
        	}
        	else
        	{
        		return "false";
        	}
        }
    }

